#ifndef BUBBLE_SORT_VISUALIZER_H
#define BUBBLE_SORT_VISUALIZER_H

void startSorting(const char *input_text);
void generateRandomValues();
void resetInput();

#endif
